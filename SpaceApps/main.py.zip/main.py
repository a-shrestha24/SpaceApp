import streamlit as st
import folium
import pandas as pd
from streamlit_folium import folium_static
from folium.plugins import HeatMap

# Title of your web app
st.title('Carbon Emissions Heatmap with Markers')

# Dropdown to select a year and the corresponding data file
file_option = st.selectbox('Select Year:', ['2022', '2018'])

# Load the corresponding emission data based on the selection
if file_option == '2022':
    data = pd.read_csv('seattle_emissions.csv')
    map_center = [47.6062, -122.3321]  # Coordinates for Seattle
else:
    data = pd.read_csv('seattle_emissions_2018.csv')
    map_center = [47.6062, -122.3321]  # Coordinates for Seattle

# Create a Folium map centered on the selected location
emission_map = folium.Map(location=map_center, zoom_start=12)

# Prepare data for the heatmap
heat_data = [[row['Latitude'], row['Longitude'], row['Emission Value']] for index, row in data.iterrows()]

# Add heatmap layer to the map
HeatMap(heat_data).add_to(emission_map)

# Add custom markers (pin points) to the map for certain locations
# Example: You can add more custom markers with different coordinates and popups
marker_locations = [
    {"location": [47.6097, -122.3331], "popup": "Marker 1: Example Location 1"},
    {"location": [47.6205, -122.3493], "popup": "Marker 2: Example Location 2"},
    {"location": [47.6080, -122.3359], "popup": "Marker 3: Example Location 3"}
]

# Adding markers to the map
for marker in marker_locations:
    folium.Marker(location=marker["location"], popup=marker["popup"]).add_to(emission_map)

# Display the map in Streamlit
folium_static(emission_map)

# Optional: Display data summary or other details
st.write("Data Summary:")
st.write(data.describe())
